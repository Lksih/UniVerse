﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniVerse
{
    public interface IMessages
    {
        void VerseAddedMessage();
    }
}
