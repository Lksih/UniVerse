﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using SQLiteNetExtensions.Attributes;

namespace UniVerse.Models
{
    [Table("Verse")]
    public class Verse
    {
        [PrimaryKey, AutoIncrement, Unique, NotNull]
        public int ID { get; set; }

        public string Name { get; set; }

        public string Text { get; set; }

        [ForeignKey(typeof(Author))]
        public int AuthorId { get; set; }

        [ForeignKey(typeof(Category))]
        public int CategoryId { get; set; }

        public int Favourited { get; set; }

        [ManyToOne]
        public Author Author { get; set; }

        [ManyToOne]
        public Category Category { get; set; }
    }
}
