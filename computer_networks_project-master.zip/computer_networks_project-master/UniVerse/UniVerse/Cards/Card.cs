﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace UniVerse
{
    internal abstract class Card
    {
        protected StackLayout CardLayout;
        //protected internal Button toList;
        internal StackLayout getCard() => CardLayout;
    }
}
