﻿using System;
using System.Collections.Generic;
using System.Text;
using UniVerse.Models;
using Xamarin.Forms;
using System.Diagnostics;

namespace UniVerse
{
    internal class VerseCard : Card
    {
        string Name;
        string Author;
        string Tags;
        int ID;
        Page ParentPage;

        internal VerseCard(Verse verse, Page page)
        {
            ParentPage = page;
            ID = verse.ID;
            Name = verse.Name;
            Author = App.Database.GetAuthor(verse.AuthorId).Name;
            Tags = "";
            foreach(var verse_tag in App.Database.GetTagsForVerse(verse.ID))
            {
                //Debug.WriteLine(verse_tag.TagId);
                Tags += App.Database.GetTag(verse_tag.TagId).Name + ", ";
            }
            if (Tags.Length > 2)
            {
                Tags = Tags.Substring(0, Tags.Length - 2);
            }
            CardLayout = new StackLayout();
            CardLayout.SetDynamicResource(StackLayout.BackgroundColorProperty, "theme");
            StackLayout header = new StackLayout { Orientation = StackOrientation.Horizontal };
            header.Children.Add(new StackLayout
            {
                Children = {
                    new Label { Text = Name },
                    new Label { Text = Author },
                    new Label { Text = Tags } }
                });
            Button learnButton = new Button { Text = "Учить" };
            learnButton.Clicked += learnPressed;
            Button testButton = new Button { Text = "Тест" };
            //testButton.Clicked += testPressed;
            CardLayout.Children.Add(header);
            CardLayout.Children.Add(learnButton);
            CardLayout.Children.Add(testButton);
        }

        public async void learnPressed(object sender, EventArgs e)
        {
            await ParentPage.Navigation.PushAsync(new VerseLearningPage(ID));
        }
    }
}
