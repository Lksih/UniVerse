﻿using System;
using System.Collections.Generic;
using System.Text;
using UniVerse.Models;
using Xamarin.Forms;

namespace UniVerse
{
    internal class VerseCard : Card
    {
        //StackLayout CardLayout;
        string Name;
        string Author;
        string Category;

        internal VerseCard(Verse verse)
        {
            Name = verse.Name;
            Author = verse.Author.Name;
            Category = verse.Category.Name;
            CardLayout = new StackLayout();
            CardLayout.SetDynamicResource(StackLayout.BackgroundColorProperty, "theme");
            StackLayout header = new StackLayout { Orientation = StackOrientation.Horizontal };
            header.Children.Add(new StackLayout
            {
                Children = {
                    new Label { Text = Name },
                    new Label { Text = Author },
                    new Label { Text = Category } }
            });
            Button test = new Button { Text = "Тест" };
            CardLayout.Children.Add(header);
            CardLayout.Children.Add(test);
        }
    }
}
