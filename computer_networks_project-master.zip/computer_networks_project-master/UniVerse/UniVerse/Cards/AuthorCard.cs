﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace UniVerse
{
    internal class AuthorCard : Card
    {
        string Name;
        string YearsLived;
        internal Button toList;

        internal AuthorCard()
        {
            Name = "Имя Фамилия";
            YearsLived = "2004-2022";
            toList = new Button { Text = "Перейти" };
            //toList.Clicked += ToListClicked;
            CardLayout = new StackLayout { Children = { 
                    new Label { Text = Name }, 
                    new Label { Text = YearsLived }, 
                    toList } };
        }

        //private async void ToListClicked(object sender, EventArgs e)
        //{
        //    await Navigation.PushAsync(new VersesPage());
        //}

        //internal StackLayout getCard() => CardLayout;
    }
}