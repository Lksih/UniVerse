﻿using System;
using System.Collections.Generic;
using System.Text;
using UniVerse.Models;
using Xamarin.Forms;

namespace UniVerse
{
    internal class AuthorCard : Card
    {
        Author CurrentAuthor;
        internal Button toList;
        Page ParentPage;

        internal AuthorCard(Author author, Page page)
        {
            CurrentAuthor = author;
            ParentPage = page;
            toList = new Button { Text = "Перейти" };
            toList.Clicked += ToListClicked;
            CardLayout = new StackLayout { Children = { 
                    new Label { Text = CurrentAuthor.Name }, 
                    toList } };
        }

        private async void ToListClicked(object sender, EventArgs e)
        {
            await ParentPage.Navigation.PushAsync(new VersesListPage(CurrentAuthor));
        }
    }
}