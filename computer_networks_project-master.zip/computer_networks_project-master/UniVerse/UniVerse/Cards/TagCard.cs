﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
using UniVerse.Models;

namespace UniVerse
{
    internal class TagCard : Card
    {
        Tag CurrentTag;
        internal Button toList;
        Page ParentPage;

        internal TagCard(Tag tag, Page page)
        {
            CurrentTag = tag;
            ParentPage = page;
            toList = new Button { Text = "Перейти" };
            toList.Clicked += ToListClicked;
            CardLayout = new StackLayout { Children = { 
                    new Label { Text = CurrentTag.Name }, 
                    toList } };
        }

        private async void ToListClicked(object sender, EventArgs e)
        {
            await ParentPage.Navigation.PushAsync(new VersesListPage(CurrentTag));
        }
    }
}
