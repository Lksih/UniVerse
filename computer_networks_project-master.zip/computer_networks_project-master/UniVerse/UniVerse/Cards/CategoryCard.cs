﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace UniVerse
{
    internal class CategoryCard : Card
    {
        string Name;
        internal Button toList;

        internal CategoryCard()
        {
            Name = "Категория";
            toList = new Button { Text = "Перейти" };
            //toList.Clicked += ToListClicked;
            CardLayout = new StackLayout { Children = { 
                    new Label { Text = Name }, 
                    toList } };
        }
    }
}
