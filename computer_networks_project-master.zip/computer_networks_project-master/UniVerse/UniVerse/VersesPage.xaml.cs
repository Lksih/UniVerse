﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UniVerse
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VersesPage : ContentPage
    {
        StackLayout VerseLayout;
        internal VersesPage(AuthorCard author)
        {
            InitializeComponent();
            VerseLayout = new StackLayout();
            for(int i = 0; i < 10; i++)
            {
                //VerseLayout.Children.Add(new VerseCard().getCard());
            }
        }
    }
}