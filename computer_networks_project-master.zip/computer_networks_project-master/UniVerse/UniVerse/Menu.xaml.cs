﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UniVerse
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Menu : TabbedPage
    {
        public Menu()
        {
            InitializeComponent();
            int rowCount = 20;
            int columnCount = 2;
            GridList authorsList = new GridList(rowCount, columnCount);
            for(int i = 0; i < columnCount; i++)
            {
                for(int j=0; j < rowCount; j++)
                {
                    authorsList.Add(new AuthorCard().getCard(), i, j);
                }
            }
            Authors.Content = authorsList.getGridListLayout();
            GridList categoriesList = new GridList(rowCount, columnCount);
            for (int i = 0; i < columnCount; i++)
            {
                for (int j = 0; j < rowCount; j++)
                {
                    categoriesList.Add(new CategoryCard().getCard(), i, j);
                }
            }
            Categories.Content = categoriesList.getGridListLayout();
        }
    }
}