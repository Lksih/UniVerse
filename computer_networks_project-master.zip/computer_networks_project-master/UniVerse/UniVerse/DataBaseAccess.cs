﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SQLite;
using UniVerse.Models;

namespace UniVerse
{
    public class DataBaseAccess
    {
        SQLiteConnection db;

        public DataBaseAccess(string dbPath)
        {
            db = new SQLiteConnection(dbPath);
        }

        public IEnumerable<Author> GetAllAuthors()
        {
            return db.Table<Author>().ToList();
        }

        public IEnumerable<Category> GetAllCategories()
        {
            return db.Table<Category>().ToList();
        }

        public IEnumerable<Verse> GetAllVerses()
        {
            return db.Table<Verse>().ToList();
        }

        public Author GetAuthor(int id){
            return db.Get<Author>(id);
        }

        public Category GetCategory(int id)
        {
            return db.Get<Category>(id);
        }

        public Verse GetVerse(int id)
        {
            return db.Get<Verse>(id);
        }
    }
}
